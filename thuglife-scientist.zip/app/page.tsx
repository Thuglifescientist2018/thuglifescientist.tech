import Image from "next/image"

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 text-center px-4">
        <h1 className="text-5xl md:text-6xl font-bold mb-4">ThuglifeScientist</h1>
        <h2 className="text-xl md:text-2xl mb-8 text-steel-blue">Started with nothing, grew up to be something</h2>

        {/* Description Section */}
        <div className="max-w-3xl mx-auto material-card p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">About ThuglifeScientist</h3>
          <div className="text-left">
            <p className="mb-4">
              [Your description will go here. This section is designed to showcase your story, mission, and vision. You
              can easily replace this placeholder text with your actual content.]
            </p>
            <p>
              The journey from nothing to something is filled with challenges, learning, and growth. This is where you
              can share that journey with the world.
            </p>
          </div>
        </div>
      </section>

      {/* Alternating Sections */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        {/* Left image, right text */}
        <div className="flex flex-col md:flex-row items-center mb-20">
          <div className="md:w-1/2 mb-6 md:mb-0 md:pr-8">
            <div className="relative h-64 md:h-96 w-full rounded-lg overflow-hidden bg-gray-200">
              <Image src="/placeholder.svg?height=400&width=600" alt="Feature image" fill className="object-cover" />
            </div>
          </div>
          <div className="md:w-1/2 material-card p-6 rounded-lg">
            <h3 className="text-2xl font-semibold mb-4">Section Title</h3>
            <p className="mb-4">
              This section uses a left image, right text layout. You can highlight key aspects of your work, philosophy,
              or achievements here.
            </p>
            <p>The material design inspired card adds depth and a modern feel to the content presentation.</p>
          </div>
        </div>

        {/* Right image, left text */}
        <div className="flex flex-col md:flex-row-reverse items-center mb-20">
          <div className="md:w-1/2 mb-6 md:mb-0 md:pl-8">
            <div className="relative h-64 md:h-96 w-full rounded-lg overflow-hidden bg-gray-200">
              <Image src="/placeholder.svg?height=400&width=600" alt="Feature image" fill className="object-cover" />
            </div>
          </div>
          <div className="md:w-1/2 material-card p-6 rounded-lg">
            <h3 className="text-2xl font-semibold mb-4">Another Section</h3>
            <p className="mb-4">
              This section uses a right image, left text layout. The alternating pattern creates visual interest and
              improves the flow of information.
            </p>
            <p>
              Steel blue accents throughout the site create a cohesive visual identity that's both professional and
              distinctive.
            </p>
          </div>
        </div>

        {/* Left image, right text */}
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-6 md:mb-0 md:pr-8">
            <div className="relative h-64 md:h-96 w-full rounded-lg overflow-hidden bg-gray-200">
              <Image src="/placeholder.svg?height=400&width=600" alt="Feature image" fill className="object-cover" />
            </div>
          </div>
          <div className="md:w-1/2 material-card p-6 rounded-lg">
            <h3 className="text-2xl font-semibold mb-4">Final Section</h3>
            <p className="mb-4">
              This is another section with left image, right text layout. You can continue the pattern as needed for
              additional content.
            </p>
            <p>The black, white, and steel blue color scheme creates a sophisticated and modern aesthetic.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
